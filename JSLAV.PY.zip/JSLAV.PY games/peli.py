import random

class Character:
    def __init__(self, name, hp, attack, defense):
        self.name = name
        self.hp = hp
        self.attack = attack
        self.defense = defense

    def take_damage(self, damage):
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0

    def is_alive(self):
        return self.hp > 0

    def attack_enemy(self, enemy):
        damage = max(0, self.attack - enemy.defense)
        enemy.take_damage(damage)
        return damage

class Player(Character):
    def __init__(self, name):
        super().__init__(name, 50, 10, 3)

    def choose_action(self):
        print("\nMitä haluat tehdä?")
        print("1. Hyökätä")
        print("2. Puolustautua")
        print("3. Ystävällinen keskustelu")
        choice = input("Valitse toiminto (1/2/3): ")
        return choice

class Enemy(Character):
    def __init__(self, name):
        super().__init__(name, 30, 8, 2)

    def attack_player(self, player):
        damage = max(0, self.attack - player.defense)
        player.take_damage(damage)
        return damage

def battle(player, enemy):
    print(f"Taistelu alkaa! {player.name} kohtaa {enemy.name}!")
    
    while player.is_alive() and enemy.is_alive():
        action = player.choose_action()
        
        if action == '1':  # Hyökkäys
            damage = player.attack_enemy(enemy)
            print(f"{player.name} iski {enemy.name}lle {damage} vahinkoa!")
        elif action == '2':  # Puolustus
            print(f"{player.name} puolustautuu!")
        elif action == '3':  # Ystävällinen keskustelu
            print(f"{player.name} yrittää keskustella {enemy.name}n kanssa...")
            # Tämä voi muuttaa taistelun kulkua, esim. hidastaa vihollisen hyökkäystä
            damage = 0
        else:
            print("Valitse toiminto oikein (1/2/3).")
            continue
        
        if enemy.is_alive():
            damage = enemy.attack_player(player)
            print(f"{enemy.name} iski {player.name}lle {damage} vahinkoa!")
        
        print(f"{player.name} HP: {player.hp} | {enemy.name} HP: {enemy.hp}")
    
    if player.is_alive():
        print(f"{player.name} voitti taistelun!")
    else:
        print(f"{player.name} hävisi taistelun.")

# Peli alkaa
player_name = input("Anna hahmosi nimi: ")
player = Player(player_name)
enemy = Enemy("Vihollinen")

battle(player, enemy)
