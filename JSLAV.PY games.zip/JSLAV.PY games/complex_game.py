import pygame
import random
import sys

WIDTH, HEIGHT = 800, 600
FPS = 60

WHITE = (255, 255, 255)
RED = (200, 0, 0)
GREEN = (0, 200, 0)
BLUE = (0, 100, 255)
BLACK = (0, 0, 0)

PLAYER_SIZE = 50
PLAYER_SPEED = 5
MAX_LIVES = 3

ENEMY_SIZE = 40
ENEMY_SPEED_BASE = 2

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Complex Python Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 24)
big_font = pygame.font.SysFont("Arial", 48)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH // 2, HEIGHT - 60)
        self.speed = PLAYER_SPEED
        self.lives = MAX_LIVES
        self.score = 0

    def update(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT:
            self.rect.y += self.speed

class Enemy(pygame.sprite.Sprite):
    def __init__(self, speed):
        super().__init__()
        self.image = pygame.Surface((ENEMY_SIZE, ENEMY_SIZE))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WIDTH - ENEMY_SIZE)
        self.rect.y = random.randint(-150, -40)
        self.speed = speed

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.rect.x = random.randint(0, WIDTH - ENEMY_SIZE)
            self.rect.y = random.randint(-150, -40)

def main():
    player = Player()
    enemies = pygame.sprite.Group()
    for i in range(6):
        enemies.add(Enemy(ENEMY_SPEED_BASE + i * 0.5))

    all_sprites = pygame.sprite.Group()
    all_sprites.add(player)
    all_sprites.add(enemies)

    running = True
    game_over = False

    while running:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        if not game_over:
            all_sprites.update(keys)
            if pygame.sprite.spritecollideany(player, enemies):
                player.lives -= 1
                if player.lives <= 0:
                    game_over = True
            player.score += 0.1

        screen.fill((135, 206, 235))
        pygame.draw.rect(screen, GREEN, (0, HEIGHT - 100, WIDTH, 100))
        for i in range(5):
            pygame.draw.ellipse(screen, WHITE, (i * 160 + (pygame.time.get_ticks() // 5) % 160, 80, 120, 60))

        all_sprites.draw(screen)

        lives_text = font.render(f"Lives: {player.lives}", True, BLACK)
        score_text = font.render(f"Score: {int(player.score)}", True, BLACK)
        screen.blit(lives_text, (10, 10))
        screen.blit(score_text, (10, 40))

        if game_over:
            go_text = big_font.render("GAME OVER", True, RED)
            screen.blit(go_text, (WIDTH // 2 - go_text.get_width() // 2, HEIGHT // 2 - go_text.get_height() // 2))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
