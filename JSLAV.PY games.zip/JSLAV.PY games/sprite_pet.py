import sys
import os
from PyQt5.QtWidgets import QApplication, QLabel, QFileDialog
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt, QTimer, QUrl
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent

class SpritePet(QLabel):
    def __init__(self):
        super().__init__()

        self.frames = [
            QPixmap("Nyanko1.png"),
            QPixmap("Nyanko2.png"),
            QPixmap("Nyanko3.png")
        ]

        self.current_frame = 0
        self.scale_factor = 5
        scaled_pixmap = self.frames[0].scaled(
            self.frames[0].width() * self.scale_factor,
            self.frames[0].height() * self.scale_factor,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        self.setPixmap(scaled_pixmap)

        # Asetukset: ilman kehystä, aina päällimmäisenä ja läpinäkyvällä taustalla
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.setFocusPolicy(Qt.NoFocus)  # Ei näppäimistöfokusta

        self.resize(scaled_pixmap.width(), scaled_pixmap.height())
        self.move_to_bottom_right()

        self.show()
        self.raise_()  # Pidä ikkuna aina päällimmäisenä

        self.speech_bubble = QLabel("", self)
        self.speech_bubble.setStyleSheet(
            "background-color: white; border: 2px solid black; border-radius: 10px; padding: 5px;"
        )
        self.speech_bubble.setFont(QFont("Arial", 14))
        self.speech_bubble.adjustSize()
        self.speech_bubble.move(0, -60)
        self.speech_bubble.hide()

        self.player = QMediaPlayer()
        self.sound_file = None

        self.frame_timer = QTimer()
        self.frame_timer.timeout.connect(self.update_frame)
        self.frame_timer.start(200)

        self.last_click_time = 0
        self.double_click_interval = QApplication.instance().doubleClickInterval()

    def move_to_bottom_right(self):
        screen = QApplication.primaryScreen().availableGeometry()
        x = screen.x() + screen.width() - self.width()
        y = screen.y() + screen.height() - self.height()
        self.move(x, y)

    def update_frame(self):
        self.current_frame = (self.current_frame + 1) % len(self.frames)
        scaled = self.frames[self.current_frame].scaled(
            self.frames[0].width() * self.scale_factor,
            self.frames[0].height() * self.scale_factor,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation,
        )
        self.setPixmap(scaled)

    def mousePressEvent(self, event):
        from time import time
        current_time = int(time() * 1000)
        if current_time - self.last_click_time < self.double_click_interval:
            self.choose_audio_file()
        else:
            self.speak()
        self.last_click_time = current_time

    def speak(self):
        self.speech_bubble.setText("Miau! 🎵")
        self.speech_bubble.adjustSize()
        self.speech_bubble.show()
        QTimer.singleShot(2000, self.speech_bubble.hide)

        if self.sound_file and os.path.exists(self.sound_file):
            url = QUrl.fromLocalFile(self.sound_file)
            self.player.setMedia(QMediaContent(url))
            self.player.play()

    def choose_audio_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Valitse musiikkitiedosto", "", "Äänet (*.mp3 *.mid *.midi);;Kaikki tiedostot (*)"
        )
        if file_path:
            self.sound_file = file_path
            print(f"Valittu äänitiedosto: {file_path}")
            self.player.setMedia(QMediaContent(QUrl.fromLocalFile(file_path)))
            self.player.play()

    def keyPressEvent(self, event):
        # Estä liikkuminen
        pass

    def moveEvent(self, event):
        # Pakota ikkuna pysymään alakulmassa, jos yritetään liikuttaa
        self.move_to_bottom_right()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    pet = SpritePet()
    sys.exit(app.exec_())

