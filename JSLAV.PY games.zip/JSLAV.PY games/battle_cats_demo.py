import pygame
import sys
import random

pygame.init()

WIDTH, HEIGHT = 800, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Battle Cats Demo")

clock = pygame.time.Clock()
FPS = 60

# Värit
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 50, 50)
GREEN = (50, 255, 50)
BLUE = (50, 50, 255)

# Perusyksikkö-luokka
class Unit:
    def __init__(self, x, y, color, speed, hp, is_enemy=False):
        self.rect = pygame.Rect(x, y, 40, 40)
        self.color = color
        self.speed = speed
        self.hp = hp
        self.is_enemy = is_enemy

    def move(self):
        if self.is_enemy:
            self.rect.x -= self.speed
        else:
            self.rect.x += self.speed

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)

    def attack(self, other):
        other.hp -= 1

def check_collision(unit_list1, unit_list2):
    for u1 in unit_list1:
        for u2 in unit_list2:
            if u1.rect.colliderect(u2.rect):
                u1.attack(u2)
                u2.attack(u1)

# Pelaajan yksiköt
player_units = []

# Vihollisen yksiköt
enemy_units = []

spawn_enemy_event = pygame.USEREVENT + 1
pygame.time.set_timer(spawn_enemy_event, 2000)  # Lisää vihollinen 2 sekunnin välein

font = pygame.font.SysFont('consolas', 24)

def draw_text(text, x, y):
    surf = font.render(text, True, WHITE)
    screen.blit(surf, (x, y))

while True:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            # Painamalla välilyönti luodaan pelaajan yksikkö kotipesästä vasemmasta reunasta
            if event.key == pygame.K_SPACE:
                player_units.append(Unit(50, HEIGHT//2 - 20, GREEN, 3, 10, is_enemy=False))
        if event.type == spawn_enemy_event:
            # Satunnainen korkeus viholliselle oikeasta reunasta
            y = random.randint(20, HEIGHT - 60)
            enemy_units.append(Unit(WIDTH - 50, y, RED, 2, 10, is_enemy=True))

    # Päivitä yksiköiden sijainnit
    for unit in player_units:
        unit.move()
    for unit in enemy_units:
        unit.move()

    # Tarkista törmäykset ja vahingot
    check_collision(player_units, enemy_units)

    # Poista kuolleet yksiköt
    player_units = [u for u in player_units if u.hp > 0]
    enemy_units = [u for u in enemy_units if u.hp > 0]

    # Piirrä yksiköt
    for unit in player_units:
        unit.draw(screen)
    for unit in enemy_units:
        unit.draw(screen)

    # Näytä ohjeet ja yksiköiden määrä
    draw_text("Paina VÄLILYÖNTI lähettääksesi kissan", 10, 10)
    draw_text(f"Pelaajan yksiköt: {len(player_units)}", 10, 40)
    draw_text(f"Viholliset: {len(enemy_units)}", 10, 70)

    pygame.display.update()
    clock.tick(FPS)
