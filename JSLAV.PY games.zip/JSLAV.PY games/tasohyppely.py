import pygame
import sys
import random

pygame.init()

# Näytön koko
WIDTH, HEIGHT = 800, 450
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tasohyppelypeli")

clock = pygame.time.Clock()
FPS = 60

# Värit
SKY_BLUE = (135, 206, 235)
GRASS_GREEN = (34, 139, 34)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
CLOUD_WHITE = (245, 245, 245)

# Maalaita
ground_height = 100
ground_rect = pygame.Rect(0, HEIGHT - ground_height, WIDTH, ground_height)

# Pelaajan ominaisuudet
player_radius = 20
player_x = 100
player_y = HEIGHT - ground_height - player_radius
player_vel_y = 0
gravity = 0.8
jump_power = -15
on_ground = True

# Viholliset (punaiset neliöt)
enemy_width = 40
enemy_height = 40
enemy_speed = 3

class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, enemy_width, enemy_height)
        self.speed = enemy_speed

    def move(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.rect.left = WIDTH + random.randint(50, 200)
            self.rect.y = HEIGHT - ground_height - enemy_height

    def draw(self, surface):
        pygame.draw.rect(surface, RED, self.rect)

# Luo vihollisia
enemies = []
for i in range(3):
    x = WIDTH + i * 250
    y = HEIGHT - ground_height - enemy_height
    enemies.append(Enemy(x, y))

# Pilvet (valkoisia ympyröitä)
clouds = []
for i in range(5):
    cx = random.randint(0, WIDTH)
    cy = random.randint(20, 100)
    clouds.append([cx, cy])

def draw_cloud(surface, x, y):
    pygame.draw.circle(surface, CLOUD_WHITE, (x, y), 20)
    pygame.draw.circle(surface, CLOUD_WHITE, (x + 25, y + 10), 18)
    pygame.draw.circle(surface, CLOUD_WHITE, (x - 20, y + 10), 15)
    pygame.draw.circle(surface, CLOUD_WHITE, (x + 10, y - 10), 18)

while True:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Näppäimistön käsittely
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_x -= 5
        if player_x - player_radius < 0:
            player_x = player_radius
    if keys[pygame.K_RIGHT]:
        player_x += 5
        if player_x + player_radius > WIDTH:
            player_x = WIDTH - player_radius
    if keys[pygame.K_SPACE] and on_ground:
        player_vel_y = jump_power
        on_ground = False

    # Pelaajan fysiikka
    player_vel_y += gravity
    player_y += player_vel_y

    # Tarkista osuuko maa
    if player_y >= HEIGHT - ground_height - player_radius:
        player_y = HEIGHT - ground_height - player_radius
        player_vel_y = 0
        on_ground = True

    # Liikuta vihollisia
    for enemy in enemies:
        enemy.move()

    # Piirrä tausta
    screen.fill(SKY_BLUE)  # Taivas

    # Piirrä pilvet
    for i, (cx, cy) in enumerate(clouds):
        draw_cloud(screen, cx, cy)
        # Pilvet liikkuu hitaasti vasemmalle
        clouds[i][0] -= 0.5
        if clouds[i][0] < -40:
            clouds[i][0] = WIDTH + 40
            clouds[i][1] = random.randint(20, 100)

    # Piirrä maa
    pygame.draw.rect(screen, GRASS_GREEN, ground_rect)

    # Piirrä pelaaja (valkoinen pallo)
    pygame.draw.circle(screen, WHITE, (int(player_x), int(player_y)), player_radius)

    # Piirrä viholliset
    for enemy in enemies:
        enemy.draw(screen)

    pygame.display.update()
