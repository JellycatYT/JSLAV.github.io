import pygame
import sys
import random

# Alusta pygame
pygame.init()

# Näytön koko
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Yksinkertainen Mato-peli')

# Värit
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Matoasetukset
snake_pos = [100, 50]
snake_body = [[100, 50], [90, 50], [80, 50]]

direction = 'RIGHT'
change_to = direction

# Ruudun koko (kuinka iso pala matoa)
block_size = 10

# Omena
food_pos = [random.randrange(1, (WIDTH//block_size)) * block_size,
            random.randrange(1, (HEIGHT//block_size)) * block_size]
food_spawn = True

# Pelin nopeus
clock = pygame.time.Clock()
speed = 15

score = 0

# Pelin fontti
font = pygame.font.SysFont('consolas', 20)

def show_score():
    score_surface = font.render(f'Score: {score}', True, WHITE)
    screen.blit(score_surface, (10, 10))

# Pääsilmukka
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        # Näppäimistöohjaus
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and direction != 'DOWN':
                change_to = 'UP'
            elif event.key == pygame.K_DOWN and direction != 'UP':
                change_to = 'DOWN'
            elif event.key == pygame.K_LEFT and direction != 'RIGHT':
                change_to = 'LEFT'
            elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                change_to = 'RIGHT'

    direction = change_to

    # Liikuta matoa
    if direction == 'UP':
        snake_pos[1] -= block_size
    elif direction == 'DOWN':
        snake_pos[1] += block_size
    elif direction == 'LEFT':
        snake_pos[0] -= block_size
    elif direction == 'RIGHT':
        snake_pos[0] += block_size

    # Mato kasvaa
    snake_body.insert(0, list(snake_pos))

    # Jos mato syö omenan
    if snake_pos == food_pos:
        score += 1
        food_spawn = False
    else:
        snake_body.pop()

    # Luo uusi omena
    if not food_spawn:
        food_pos = [random.randrange(1, (WIDTH//block_size)) * block_size,
                    random.randrange(1, (HEIGHT//block_size)) * block_size]
        food_spawn = True

    # Täytä tausta
    screen.fill(BLACK)

    # Piirrä mato
    for pos in snake_body:
        pygame.draw.rect(screen, GREEN, pygame.Rect(pos[0], pos[1], block_size, block_size))

    # Piirrä omena
    pygame.draw.rect(screen, RED, pygame.Rect(food_pos[0], food_pos[1], block_size, block_size))

    # Tarkista törmäykset
    # Seinät
    if snake_pos[0] < 0 or snake_pos[0] >= WIDTH or snake_pos[1] < 0 or snake_pos[1] >= HEIGHT:
        pygame.quit()
        sys.exit()
    # Mato itseensä
    for block in snake_body[1:]:
        if snake_pos == block:
            pygame.quit()
            sys.exit()

    show_score()

    pygame.display.update()
    clock.tick(speed)
