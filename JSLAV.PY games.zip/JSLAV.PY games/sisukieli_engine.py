import pygame
import sys

class SisukieliEngine:
    def __init__(self):
        self.dictionary = {
            "sni": "sinä",
            "mi": "minä",
            "vi": "me",
            "hin": "hän",
            "det": "nämä",
            "nun": "nuo",
            "kji": "kiva",
            "ti": "on",
            "Di": "onko",
            "im": "olen",
            "tik": "tieto",
            "keo": "kone",
            "ne": "moi",
            "xu": "paha",
            "hih": "hyvä",
            "åä": "laiska",
            "kjo": "kemia",
            "par": "paperi",
            "urx": "sota",
            "jif": "julistaa",
            "jivi,u": "te",
            "tj": "tämä",
            "jun": "vuosi",
            "nit": "nyt",
            "vps": "vesi",
            "ps": "pallo",
            "vxu": "tuli",
            "mu": "maa",
            "du": "mikä",
            "lj": "suru",
            "ejn": "pyyhekumi",
            "ru": "raha",
            "xjx": "kuolema",
            "jih": "nimi",
            "jij": "huono",
            "djn": "tavallinen",
            "han": "huomenta",
            "pae": "peli",
            "jih,aej,ej": "haluan",
            "sun": "takaisin",
            "en": "ei",
            "naj": "kissa",
            "mo": "mieti",
            "un": "ole",
            "at": "aika",
            "ts": "sekunti",
            "ms": "minuutti",
            "tn": "tunti",
            "pic": "päivä",
            "vix": "viikko",
            "knt": "kuukausi",
            "kuk": "kehitynyt",
            "guxn": "strategia",
            "lxf": "loppu",
            "axn": "alku",
            "sux": "ideologia",
            "ous": "osa",
            "rxg": "viimeinen",
            "so": "sivu",
            "jb": "kyllä",
            "tp": "tapa",
            "eä": "elämä",
            "kau": "kirja",
            "kee": "kieli",
            "fin": "suomi",
            "dj": "miksi",
            "vpv": "vaikea",
            "gn": "mene",
            "jn": "yhtälö",
            "lu": "jako",
            "pu": "pienenmpi",
            "su": "suurempi",
            "ex": "energia"
        }

    def translate(self, codes):
        words = []
        for code in codes:
            if code in self.dictionary:
                words.append(self.dictionary[code])
            else:
                words.append(f"[{code}]")  # Näytä tuntemattomat koodit hakasulkeissa
        return " ".join(words)

def main():
    pygame.init()

    # Näytön koko
    width, height = 640, 120
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Sisukieli-kääntäjä")

    # Lataa fontti (tässä tiedostopolku samaan kansioon)
    font_path = "sisu-kieli (6).ttf"
    font_size = 48
    try:
        font = pygame.font.Font(font_path, font_size)
    except FileNotFoundError:
        print(f"Fonttitiedostoa '{font_path}' ei löytynyt.")
        pygame.quit()
        sys.exit()

    engine = SisukieliEngine()

    # Kysy käyttäjältä koodit tekstinä
    user_input = input("Anna Sisukieli-teksti (erota koodit välilyönneillä):\n")
    codes = user_input.strip().split()

    translated_text = engine.translate(codes)

    # Renderöi teksti
    text_surface = font.render(translated_text, True, (255, 255, 255))  # valkoinen teksti
    text_rect = text_surface.get_rect(center=(width // 2, height // 2))

    clock = pygame.time.Clock()
    running = True
    while running:
        screen.fill((0, 0, 0))  # musta tausta
        screen.blit(text_surface, text_rect)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        clock.tick(30)

    pygame.quit()

if __name__ == "__main__":
    main()
