import tkinter as tk
from tkinter import scrolledtext, messagebox
import requests
from youtubesearchpython import VideosSearch
from bs4 import BeautifulSoup
import yt_dlp
import os
import subprocess
import platform
import ast
import operator
import webview

# Avataan ikkuna, jossa näkyy haluttu nettisivu
webview.create_window('Nettisivu', 'https://jellycatyt.github.io/JSLAV.github.io/index.html')
webview.start()



# Turvallinen eval ilman eval()-funktiota: sallitaan vain matemaattiset operaatiot
class SafeEval(ast.NodeVisitor):
    operators = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.Mod: operator.mod,
    }

    def visit(self, node):
        if isinstance(node, ast.Expression):
            return self.visit(node.body)
        elif isinstance(node, ast.Num):  # < Python 3.8
            return node.n
        elif isinstance(node, ast.Constant):  # Python 3.8+
            if isinstance(node.value, (int, float)):
                return node.value
            else:
                raise ValueError("Vain numeroita sallitaan")
        elif isinstance(node, ast.BinOp):
            left = self.visit(node.left)
            right = self.visit(node.right)
            op_type = type(node.op)
            if op_type in self.operators:
                return self.operators[op_type](left, right)
            else:
                raise ValueError("Operaattori ei sallittu")
        elif isinstance(node, ast.UnaryOp):
            operand = self.visit(node.operand)
            op_type = type(node.op)
            if op_type in self.operators:
                return self.operators[op_type](operand)
            else:
                raise ValueError("Operaattori ei sallittu")
        else:
            raise ValueError("Vain matemaattiset lausekkeet sallitaan")


def safe_eval(expr):
    try:
        tree = ast.parse(expr, mode='eval')
        return SafeEval().visit(tree)
    except Exception as e:
        raise ValueError(f"Virheellinen laskutoimitus: {e}")


def lataa_video(url, kohde_kansio="ladatut_videot"):
    if not os.path.exists(kohde_kansio):
        os.makedirs(kohde_kansio)

    ydl_opts = {
        'outtmpl': os.path.join(kohde_kansio, '%(title)s.%(ext)s'),
        'format': 'bestvideo+bestaudio/best',
        'quiet': True,
        'no_warnings': True
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            tiedosto = ydl.prepare_filename(info)
            return tiedosto
    except Exception as e:
        return f"Virhe ladattaessa videota: {e}"


def avaa_video(tiedosto):
    try:
        if platform.system() == 'Darwin':       # macOS
            subprocess.call(('open', tiedosto))
        elif platform.system() == 'Windows':    # Windows
            os.startfile(tiedosto)
        else:                                   # Linux ja muut
            subprocess.call(('xdg-open', tiedosto))
    except Exception as e:
        messagebox.showerror("Virhe", f"Videota ei voitu avata: {e}")


class OS_GUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("JSLAVOS GUI")
        self.geometry("600x450")
        self.configure(bg="black")

        self.apps = {
            "Muistio": self.muistio,
            "Laskin": self.laskin,
            "Simuloitu selain (Wikipedia)": self.selain,
            "YT-X YouTube-haku": self.ytx,
            "Google-haku": self.google,
            "Lataa YouTube-video": self.lataa_ja_avaa_video
        }

        label = tk.Label(self, text="Valitse sovellus", font=("Consolas", 18), fg="lime", bg="black")
        label.pack(pady=15)

        for app_name in self.apps.keys():
            btn = tk.Button(self, text=app_name, width=30, font=("Consolas", 14), command=self.apps[app_name],
                            bg="black", fg="lime", activebackground="lime", activeforeground="black")
            btn.pack(pady=6)

    def muistio(self):
        win = tk.Toplevel(self)
        win.title("Muistio")
        win.geometry("500x400")
        win.configure(bg="black")

        txt = scrolledtext.ScrolledText(win, wrap=tk.WORD, font=("Consolas", 12), bg="black", fg="lime",
                                        insertbackground="lime")
        txt.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        def save_and_close():
            content = txt.get("1.0", tk.END).strip()
            if content:
                messagebox.showinfo("Muistio", "Muistio tallennettu. Sisältö:\n\n" + content)
            win.destroy()

        btn_save = tk.Button(win, text="Tallenna ja Sulje", font=("Consolas", 14), command=save_and_close, bg="black",
                             fg="lime", activebackground="lime", activeforeground="black")
        btn_save.pack(pady=10)

    def laskin(self):
        win = tk.Toplevel(self)
        win.title("Laskin")
        win.geometry("350x180")
        win.configure(bg="black")

        entry = tk.Entry(win, font=("Consolas", 18), bg="black", fg="lime", insertbackground="lime")
        entry.pack(pady=15, padx=15, fill=tk.X)

        result_label = tk.Label(win, text="", font=("Consolas", 16), fg="lime", bg="black")
        result_label.pack(pady=5)

        def laske():
            expr = entry.get()
            if expr.strip() == "":
                result_label.config(text="Anna laskutoimitus")
                return
            try:
                tulos = safe_eval(expr)
                result_label.config(text=f"Tulos: {tulos}")
            except Exception as e:
                result_label.config(text=str(e))

        btn_calc = tk.Button(win, text="Laske", font=("Consolas", 14), command=laske, bg="black", fg="lime",
                             activebackground="lime", activeforeground="black")
        btn_calc.pack(pady=10)

    def selain(self):
        win = tk.Toplevel(self)
        win.title("Simuloitu selain (Wikipedia)")
        win.geometry("600x450")
        win.configure(bg="black")

        entry = tk.Entry(win, font=("Consolas", 16), bg="black", fg="lime", insertbackground="lime")
        entry.pack(pady=10, fill=tk.X, padx=10)

        txt = scrolledtext.ScrolledText(win, wrap=tk.WORD, font=("Consolas", 12), bg="black", fg="lime",
                                        insertbackground="lime")
        txt.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)

        def hae():
            hakusana = entry.get().strip()
            txt.delete("1.0", tk.END)
            if not hakusana:
                return
            try:
                url = f"https://fi.wikipedia.org/wiki/{hakusana.replace(' ', '_')}"
                response = requests.get(url)
                if response.status_code != 200:
                    txt.insert(tk.END, "Hakua ei löytynyt.")
                    return
                soup = BeautifulSoup(response.text, "html.parser")
                kappaleet = soup.find_all("p")
                for p in kappaleet:
                    teksti = p.get_text().strip()
                    if teksti:
                        txt.insert(tk.END, teksti[:1000] + "\n\n")
                        break
            except Exception as e:
                txt.insert(tk.END, f"Virhe haussa: {e}")

        btn = tk.Button(win, text="Hae", font=("Consolas", 14), command=hae, bg="black", fg="lime",
                        activebackground="lime", activeforeground="black")
        btn.pack(pady=10)

    def ytx(self):
        win = tk.Toplevel(self)
        win.title("YT-X YouTube-haku")
        win.geometry("600x450")
        win.configure(bg="black")

        entry = tk.Entry(win, font=("Consolas", 16), bg="black", fg="lime", insertbackground="lime")
        entry.pack(pady=10, fill=tk.X, padx=10)

        txt = scrolledtext.ScrolledText(win, wrap=tk.WORD, font=("Consolas", 12), bg="black", fg="lime",
                                        insertbackground="lime")
        txt.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)

        def haku():
            hakusana = entry.get().strip()
            txt.delete("1.0", tk.END)
            if not hakusana:
                return
            try:
                videosSearch = VideosSearch(hakusana, limit=5)
                tulokset = videosSearch.result().get('result', [])
                if not tulokset:
                    txt.insert(tk.END, "Hakutuloksia ei löytynyt.")
                    return
                for idx, video in enumerate(tulokset, start=1):
                    otsikko = video.get('title', 'Ei otsikkoa')
                    kesto = video.get('duration', 'Tuntematon kesto')
                    url = video.get('link', '')
                    txt.insert(tk.END, f"{idx}. {otsikko} ({kesto})\n{url}\n\n")
            except Exception as e:
                txt.insert(tk.END, f"Virhe haussa: {e}")

        btn = tk.Button(win, text="Hae YouTubesta", font=("Consolas", 14), command=haku, bg="black", fg="lime",
                        activebackground="lime", activeforeground="black")
        btn.pack(pady=10)

    def google(self):
        win = tk.Toplevel(self)
        win.title("Google-haku")
        win.geometry("600x450")
        win.configure(bg="black")

        entry = tk.Entry(win, font=("Consolas", 16), bg="black", fg="lime", insertbackground="lime")
        entry.pack(pady=10, fill=tk.X, padx=10)

        txt = scrolledtext.ScrolledText(win, wrap=tk.WORD, font=("Consolas", 12), bg="black", fg="lime",
                                        insertbackground="lime")
        txt.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)

        def haku():
            hakusana = entry.get().strip()
            txt.delete("1.0", tk.END)
            if not hakusana:
                return
            try:
                url = f"https://www.google.com/search?q={hakusana}"
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                }
                response = requests.get(url, headers=headers)
                if response.status_code != 200:
                    txt.insert(tk.END, "Hakua ei löytynyt.")
                    return
                soup = BeautifulSoup(response.text, "html.parser")
                results = soup.find_all('div', class_='BNeawe vvjwJb AP7Wnd', limit=5)
                if not results:
                    txt.insert(tk.END, "Hakutuloksia ei löytynyt.")
                    return
                for idx, res in enumerate(results, start=1):
                    teksti = res.get_text()
                    txt.insert(tk.END, f"{idx}. {teksti}\n\n")
            except Exception as e:
                txt.insert(tk.END, f"Virhe haussa: {e}")

        btn = tk.Button(win, text="Hae Googlella", font=("Consolas", 14), command=haku, bg="black", fg="lime",
                        activebackground="lime", activeforeground="black")
        btn.pack(pady=10)

    def lataa_ja_avaa_video(self):
        win = tk.Toplevel(self)
        win.title("Lataa YouTube-video")
        win.geometry("400x180")
        win.configure(bg="black")

        entry = tk.Entry(win, font=("Consolas", 14), bg="black", fg="lime", insertbackground="lime")
        entry.pack(pady=20, padx=20, fill=tk.X)

        def lataa():
            url = entry.get().strip()
            if not url:
                messagebox.showwarning("Varoitus", "Anna YouTube-videon URL-osoite.")
                return
            tulos = lataa_video(url)
            if tulos.startswith("Virhe"):
                messagebox.showerror("Virhe", tulos)
            else:
                messagebox.showinfo("Valmis", f"Video ladattu:\n{tulos}")
                avaa_video(tulos)

        btn = tk.Button(win, text="Lataa ja avaa", font=("Consolas", 14), command=lataa, bg="black", fg="lime",
                        activebackground="lime", activeforeground="black")
        btn.pack(pady=10)


if __name__ == "__main__":
    app = OS_GUI()
    app.mainloop()

